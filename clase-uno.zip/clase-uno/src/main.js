import Vue from 'vue'
import App from './App.vue'
import router from './router'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

import { initializeApp } from "firebase/app";
//import { getFirestore, collection, getDocs} from 'firebase/firestore/lite'

const firebaseConfig = {
  apiKey: "AIzaSyDqaqAFM7ymvk8G-7JJXmiMxs1lp5UpyXU",
  authDomain: "clase-uno-3e5a6.firebaseapp.com",
  projectId: "clase-uno-3e5a6",
  storageBucket: "clase-uno-3e5a6.appspot.com",
  messagingSenderId: "602032640065",
  appId: "1:602032640065:web:1be4aefd8f464dce8676c0"
};

//const app = initializeApp(firebaseConfig);
initializeApp(firebaseConfig);

//const app = initializeApp(firebaseConfig);
//const db = getFirestore(app);
//
//// Get a list of cities from your database
//async function getCities(db) {
//  const citiesCol = collection(db, 'cities');
//  const citySnapshot = await getDocs(citiesCol);
//  const cityList = citySnapshot.docs.map(doc => doc.data());
//  return cityList;
//}


Vue.config.productionTip = false;
Vue.use(ElementUI);

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
