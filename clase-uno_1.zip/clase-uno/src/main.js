import Vue from 'vue'
import App from './App.vue'
import router from './router'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAlja3jjxWWbri4DNEUUP_634jmUFlGB1w",
  authDomain: "claseuno-90df9.firebaseapp.com",
  projectId: "claseuno-90df9",
  storageBucket: "claseuno-90df9.appspot.com",
  messagingSenderId: "75491765602",
  appId: "1:75491765602:web:2a3919e63348b1fe07503b"
};

// Initialize Firebase
initializeApp(firebaseConfig);

Vue.use(ElementUI);
Vue.config.productionTip = false;

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
